#!/usr/bin/env python
"""
Script to compute pooled EER for ASVspoof2021 DF. 
Usage:
$: python PATH_TO_SCORE_FILE PATH_TO_GROUDTRUTH_DIR phase
 
 -PATH_TO_SCORE_FILE: path to the score file 
 -PATH_TO_GROUNDTRUTH_DIR: path to the directory that has the CM protocol.
    Please follow README, download the key files, and use ./keys
 -phase: either progress, eval, or hidden_track
Example:
$: python evaluate.py score.txt ./keys eval
"""
import sys, os.path
import numpy as np
import pandas
import eval_metrics_DF as em
from glob import glob

# if len(sys.argv) != 4:
#     print("CHECK: invalid input arguments. Please read the instruction below:")
#     print(__doc__)
#     exit(1)

# submit_file = sys.argv[1]
# truth_dir = sys.argv[2]
# phase = sys.argv[3]

# cm_key_file = os.path.join(truth_dir, 'CM/trial_metadata.txt')

# submit_file = "AD_eval_CM_scores_file_SSL_arabic_dataset_40epoch.txt"
# truth_dir = 'D:/arabic_audio_dataset/renamed_dataset/'
# phase = "eval"

# cm_key_file = 'D:/arabic_audio_dataset/renamed_dataset/metadata-eval.txt'


submit_file = "D:/Hafsa/DeepGuard/Paper1/aasist-main/exp_result/urdu_AASIST_ep25_bs24/cw10_unispeech_urdu_AASIST_ep25_bs24_mss_urdu_eval_scores_using_best_dev_model.txt"
phase = "eval"

cm_key_file = "D:/datasets/audio/MSS_Adv_attacked/MSS_urdu/MSS_urdu_cm_protocols/cm.eval.trl.txt"

def eval_to_score_file(score_file, cm_key_file):
    
    cm_data = pandas.read_csv(cm_key_file, sep=' ', header=None)
    submission_scores = pandas.read_csv(score_file, sep=' ', header=None, skipinitialspace=True)
    if len(submission_scores) != len(cm_data):
        print('CHECK: submission has %d of %d expected trials.' % (len(submission_scores), len(cm_data)))
        exit(1)

    # if len(submission_scores.columns) > 2:
    #     print('CHECK: submission has more columns (%d) than expected (2). Check for leading/ending blank spaces.' % len(submission_scores.columns))
    #     exit(1)
            
    
    
    cm_scores = submission_scores.merge(cm_data[cm_data[4] == '-'], left_on=0, right_on=1, how='inner')  # check here for progress vs eval set
    print(cm_scores)
    bona_cm = cm_scores[cm_scores[3] == 'bonafide']['1_x'].values
    spoof_cm = cm_scores[cm_scores[3] == 'spoof']['1_x'].values
    print(cm_data[cm_data[3] == "bonafide"].head())
    print("Bonafide in protocol:", (cm_data[3] == "bonafide").sum())
    bona_ids = set(cm_data[cm_data[3] == "bonafide"][1])
    score_ids = set(submission_scores[0])

    print("Matched bonafide IDs:", len(bona_ids & score_ids))
    print("Total bonafide IDs:", len(bona_ids))
    print("Bonafide scores:", len(bona_cm))
    print("Spoof scores:", len(spoof_cm))
    print("Unique labels:", cm_scores[3].unique())
    print(cm_scores[3].value_counts())
    eer_cm = em.compute_eer(bona_cm, spoof_cm)[0]
    out_data = "eer: %.2f\n" % (100*eer_cm)
    print(out_data)
    return eer_cm

if __name__ == "__main__":

    if not os.path.isfile(submit_file):
        print("%s doesn't exist" % (submit_file))
        exit(1)
        
    # if not os.path.isdir(truth_dir):
    #     print("%s doesn't exist" % (truth_dir))
    #     exit(1)

    if phase != 'progress' and phase != 'eval' and phase != 'hidden_track':
        print("phase must be either progress, eval, or hidden_track")
        exit(1)

    _ = eval_to_score_file(submit_file, cm_key_file)
